# BIMSpend — Continuation Context for Any AI Agent

You are continuing an exploratory product brainstorm. Do not assume implementation is authorized.

**User goal:** Explore a commercial subscription software concept for BIM/engineering teams. Potentially monitor Revit and other Autodesk applications automatically, with zero routine action by designers. A manager on another PC sees all users, projects, time and costs. Potential differentiator: compare actual effort, charged effort and internal cost to improve estimating/quoting.

**Status:** Product purpose and integration are not settled. User explicitly says time tracking vs pricing assistance may become the same product, but this is a hypothesis.

**Prior discussions:** A single Windows installer would provision desktop agent plus compatible Autodesk integrations. Launch automatically with Windows/Revit; no daily login or timer. Manager access likely web/cloud but architecture undecided. Multiple Revit versions require version-specific integration builds. Multiple simultaneously open models require non-duplicated accounting. Need robust model-to-commercial-project mapping, offline persistence, employee transparency and security.

**Market:** Revit tracking already exists (Time Tracker Pro, Project Tracker, INFINITY Time Summary). ManicTime is a relevant cross-app tracker. Therefore basic automatic time tracking is not novel. Investigate differentiated estimating and cost intelligence; no originality/patent claim established.

**Historical data:** User's PC has 101 Revit Journal text files across Revit 2021–2026; these may allow partial reconstruction of sessions, not proven hours. No parsing result yet. See docs/03.

**Commercial data:** Two spreadsheets were shared in chat: `Item price list.xlsx` and `Maria Angelica Sales by Product_Service Detail.xlsx`. They contain company-specific rates and invoices. Do NOT commit raw spreadsheets or identifiable employee/customer data. User clarified report Quantity × rate reflects hours CHARGED to clients, not necessarily hours ACTUALLY worked; sometimes the company discounts billable hours subjectively. This gap is central.

**Brand:** BIMSpend is a working name. User screenshot showed bimspend.com offered for sale at A$17.22 first year (time-dependent). ASIC/IP Australia/domain registration clearance NOT confirmed.

**Interaction style:** Discuss one important product question at a time; keep a running decision log; distinguish facts, proposals and uncertainties. Prefer useful diagrams and financial examples. Never imply a feature is already built.

**Next useful question:** How does the company currently know actual hours spent when it invoices fewer hours? Is there a manual timesheet, a manager estimate, or other data source?

**Update protocol:** After each discussion update relevant docs, append a dated note to docs/06-DECISION-LOG.md, and optionally open an Issue. Keep changes in GitHub private until cleared for publication.
