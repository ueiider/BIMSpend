# Visual gallery

These SVGs are editable vector **reconstructions** of the conversation's visual concepts, not exact copies of the chat's interactive dashboards or third-party product screenshots.

- [System concept](architecture.svg)
- [Tracking → costing → quoting](value-chain.svg)
- [Manager dashboard concept](manager-dashboard.svg)
- [Actual vs billed time](billing-gap.svg)
- [Journal inventory](journal-counts.svg)

Additional conceptual UI discussed in chat: subscription tiers, Revit timer, per-file project analytics, new-project estimate slider, project financial simulator, potential revenue simulator. Their inputs/formulas are in `docs/05-PRICING-AND-DATA.md` and `examples/illustrative-scenarios.csv`.
